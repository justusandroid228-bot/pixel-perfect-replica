# Just Us — Kotlin Native Android (Phase 1)

This is a **real Android-native Jetpack Compose project**. It does not embed the existing React app and does not use Capacitor or WebView.

## What was carried over from the uploaded source

The existing project is React + TypeScript + TanStack Start with Supabase and Capacitor 8. Its app ID is `app.justus.messenger`. The native project keeps that application ID and maps the existing screens/features:

- Welcome / brand screen and romantic rose palette
- Email login and sign-up screen layouts
- Pairing / invitation-code screen layout
- Chat conversation layout and composer
- Settings / privacy / preference screen layout

## Important implementation status

This is the **native UI foundation**, not a feature-complete replacement yet. The visible forms and chat composer are currently preview interactions. Supabase modules and a native client provider are included, but authentication, room RPCs, message persistence, Realtime subscriptions, media upload, receipts, typing status, preferences, password reset and deep-link verification still need to be wired and tested before production use. Do not distribute this preview as a finished messenger.

## Supabase configuration

The original `.env` was intentionally not copied into this project. Configure the public project URL and publishable key locally in `local.properties` (never commit it):

```properties
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
```

A publishable/anon key is expected in a mobile client; **never put a Supabase service-role or secret key in the APK**. Your existing Supabase database schema and RLS policies remain the source of truth.

## Build

Open this folder in Android Studio (JDK 17, Android SDK 36), allow Gradle sync, then run `app` on a device/emulator. Or from this folder:

```bash
gradle :app:assembleDebug
```

The output will be `app/build/outputs/apk/debug/app-debug.apk`.

## Existing app signature

The original Capacitor app uses the same package ID. To update an installed release without uninstalling, the native APK must be signed with the **same existing release keystore** and have a higher `versionCode`. The included release workflow expects the repository secrets already documented by the original project:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Never upload a debug-signed APK over a release-signed installation.

## Migration plan

1. Wire Supabase Auth + secure session persistence and redirect/deep links.
2. Implement room state, create invitation, revoke invitation and join room using the existing RPCs (`create_room`, `create_invitation`, `active_invitation`, `revoke_invitations`, `join_room`).
3. Implement message history, text/sticker/media sending, receipts and Realtime subscriptions using the existing schema.
4. Implement settings, preferences, privacy page and password reset.
5. Add native notifications, media picker/camera, lifecycle handling, accessibility and offline/error states.
6. Test against the real Supabase project and generate a signed release APK/AAB.

Source reference: uploaded `pixel-perfect-replica-main 2.zip`, especially `src/routes`, `src/components/chat`, `src/lib`, and `drizzle/migrations/0000_migration.sql`.
