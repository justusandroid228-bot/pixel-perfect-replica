package app.justus.messenger.data

import app.justus.messenger.BuildConfig
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.storage.Storage

/** Native Supabase client. Only the public/publishable key belongs in a mobile app. */
object SupabaseProvider {
    val client by lazy {
        check(BuildConfig.SUPABASE_URL.isNotBlank()) { "Missing SUPABASE_URL build property" }
        check(BuildConfig.SUPABASE_PUBLISHABLE_KEY.isNotBlank()) { "Missing SUPABASE_PUBLISHABLE_KEY build property" }
        createSupabaseClient(
            supabaseUrl = BuildConfig.SUPABASE_URL,
            supabaseKey = BuildConfig.SUPABASE_PUBLISHABLE_KEY
        ) {
            install(Auth)
            install(Postgrest)
            install(Realtime)
            install(Storage)
        }
    }
}
