package app.justus.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.justus.messenger.ui.JustUsTheme

private val Rose = Color(0xFFE96B83)
private val Ink = Color(0xFF583B48)
private val Muted = Color(0xFF927D86)
private val Paper = Color(0xFFFFF9F8)
private val Bg = Brush.verticalGradient(listOf(Color(0xFFFFF1F3), Color(0xFFFFF8F5), Color(0xFFFFEEF2)))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JustUsTheme { JustUsRoot() } }
    }
}

private enum class Page { Welcome, Login, Signup, Pairing, Chat, Settings }

@Composable
private fun JustUsRoot() {
    var page by remember { mutableStateOf(Page.Welcome) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var invite by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Some conversations are meant for two. 💗")) }
    var banner by remember { mutableStateOf("Native UI preview · backend connection is the next integration step") }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            when (page) {
                Page.Welcome -> WelcomeScreen(
                    onCreate = { page = Page.Signup }, onLogin = { page = Page.Login }
                )
                Page.Login, Page.Signup -> AuthScreen(
                    signup = page == Page.Signup,
                    email = email, onEmail = { email = it },
                    password = password, onPassword = { password = it },
                    name = displayName, onName = { displayName = it },
                    notice = banner,
                    onSubmit = { banner = "Supabase Auth wiring is pending; credentials are not sent in this preview." },
                    onSwitch = { page = if (page == Page.Login) Page.Signup else Page.Login },
                    onBack = { page = Page.Welcome }
                )
                Page.Pairing -> PairingScreen(
                    invite = invite, onInvite = { invite = it },
                    onCreateRoom = { banner = "Room creation will call the existing create_room() RPC." },
                    onJoin = { banner = "Joining will call the existing join_room(_code) RPC." },
                    onSettings = { page = Page.Settings }, notice = banner
                )
                Page.Chat -> ChatScreen(
                    messages = messages, draft = draft, onDraft = { draft = it },
                    onSend = { if (draft.isNotBlank()) { messages = messages + draft.trim(); draft = "" } },
                    onSettings = { page = Page.Settings }
                )
                Page.Settings -> SettingsScreen(onBack = { page = Page.Chat }, onSignOut = { page = Page.Welcome })
            }
        }
    }
}

@Composable
private fun BrandMark(size: Int = 82) {
    Box(Modifier.size(size.dp).shadow(16.dp, CircleShape).background(Color.White.copy(alpha = .82f), CircleShape), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.Favorite, null, tint = Rose, modifier = Modifier.size((size * .47).dp))
        Icon(Icons.Filled.FavoriteBorder, null, tint = Color(0xFFFFB5C1), modifier = Modifier.size((size * .72).dp))
    }
}

@Composable
private fun WelcomeScreen(onCreate: () -> Unit, onLogin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
        Spacer(Modifier.height(12.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandMark(96)
            Spacer(Modifier.height(26.dp))
            Text("Just Us", fontSize = 48.sp, fontWeight = FontWeight.SemiBold, color = Ink, letterSpacing = (-1).sp)
            Spacer(Modifier.height(8.dp))
            Text("Some conversations are meant for two.", color = Muted, fontSize = 17.sp, fontStyle = FontStyle.Italic, textAlign = TextAlign.Center)
        }
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PrimaryButton("Create our space", onCreate)
            OutlinedButton(onClick = onLogin, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(30.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink)) { Text("I already have an account", fontWeight = FontWeight.SemiBold) }
            Text("Privacy notice", Modifier.fillMaxWidth(), color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun AuthScreen(signup: Boolean, email: String, onEmail: (String) -> Unit, password: String, onPassword: (String) -> Unit, name: String, onName: (String) -> Unit, notice: String, onSubmit: () -> Unit, onSwitch: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("‹  Back", Modifier.fillMaxWidth(), color = Ink, fontSize = 17.sp)
        Spacer(Modifier.weight(1f))
        BrandMark(60)
        Spacer(Modifier.height(18.dp))
        Text(if (signup) "Create your account" else "Welcome back", color = Ink, fontSize = 31.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .86f)), shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (signup) NativeField("What should they call you?", name, onName)
                NativeField("Email", email, onEmail)
                OutlinedTextField(password, onPassword, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(14.dp))
                Text(notice, color = Muted, fontSize = 11.sp)
                PrimaryButton(if (signup) "Sign up" else "Log in", onSubmit)
            }
        }
        TextButton(onClick = onSwitch) { Text(if (signup) "Have an account? Log in" else "New here? Sign up", color = Ink) }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun NativeField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp))
}

@Composable
private fun PairingScreen(invite: String, onInvite: (String) -> Unit, onCreateRoom: () -> Unit, onJoin: () -> Unit, onSettings: () -> Unit, notice: String) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Just Us", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Ink) } }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) { BrandMark(68); Spacer(Modifier.height(18.dp)); Text("Your private space", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.SemiBold); Text("Create a room for two, or join the one your partner made.", color = Muted, textAlign = TextAlign.Center) }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .88f)), shape = RoundedCornerShape(26.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Invite your partner", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("You'll get a one-time code that expires in 24 hours.", color = Muted, fontSize = 13.sp)
                PrimaryButton("Create our room / Get a code", onCreateRoom)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .88f)), shape = RoundedCornerShape(26.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Have a code?", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(invite, onInvite, modifier = Modifier.fillMaxWidth(), label = { Text("JU-XXXX-XXXX") }, singleLine = true, shape = RoundedCornerShape(14.dp))
                OutlinedButton(onClick = onJoin, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(28.dp)) { Text("Join", color = Ink) }
            }
        }
        Text(notice, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ChatScreen(messages: List<String>, draft: String, onDraft: (String) -> Unit, onSend: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Column { Text("Just Us", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Your private space for two", color = Muted, fontSize = 12.sp) }; Spacer(Modifier.weight(1f)); IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Ink) } }
        HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Rose.copy(alpha = .18f))
        Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            messages.forEachIndexed { i, msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (i % 2 == 0) Arrangement.Start else Arrangement.End) {
                    Surface(color = if (i % 2 == 0) Color.White else Color(0xFFFFDDE4), shape = RoundedCornerShape(20.dp)) { Text(msg, Modifier.widthIn(max = 290.dp).padding(horizontal = 15.dp, vertical = 11.dp), color = Ink) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(draft, onDraft, modifier = Modifier.weight(1f), placeholder = { Text("Write a message…") }, shape = RoundedCornerShape(26.dp), maxLines = 4)
            Button(onClick = onSend, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Rose), contentPadding = PaddingValues(16.dp)) { Text("➤", color = Color.White) }
        }
    }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit, onSignOut: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("‹  Settings", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        listOf("Your space", "Account", "Notifications & privacy", "In-app notifications", "Message sound", "Share typing status", "Privacy notice").forEach { item ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .86f)), shape = RoundedCornerShape(18.dp)) { Text(item, Modifier.fillMaxWidth().padding(17.dp), color = Ink, fontWeight = FontWeight.Medium) }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(28.dp)) { Text("Log out", color = Rose) }
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Back to chat", color = Ink) }
    }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(30.dp), colors = ButtonDefaults.buttonColors(containerColor = Rose), elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp)) { Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
}
