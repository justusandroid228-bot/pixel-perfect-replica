package app.justus.messenger.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = lightColorScheme(
    primary = Color(0xFFE96B83), onPrimary = Color.White,
    secondary = Color(0xFFFFDDE4), onSecondary = Color(0xFF583B48),
    background = Color(0xFFFFF5F6), surface = Color(0xFFFFF9F8),
    onSurface = Color(0xFF583B48)
)

@Composable
fun JustUsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
